package scope.more;

public class Employee {
	private String id;

	public Employee(String theId) {
		id = theId;
	}

	public String getId() {
		return id;
	}
}
