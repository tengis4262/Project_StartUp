package scope.more;

public class Book {

	private String id;

	public Book(String theId) {
		id = theId;
	}

	public String getId() {
		return id;
	}
}
